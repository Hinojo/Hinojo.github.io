# PGATR_PR1

Practica 1 de la asignatura PGATR...

--GUIA PARA MONTAR EL SERVER (y poder usar XMLHTTPRequest)
1. Instala Python (la nueva version es la 3.7)
2. muevete con powerShell (o la terminal de Code) a la carpeta donde esté todo el código
3. escribe: py -m http.server
* Verás que se cargará un servidor, con los archivos que estamos usando.
4. desde el navegador, accede a: localhost:[NUMERO DEL SERVIDOR]

--ACABA GUIA--

Trabajo que queda por hacer: 

* Uso de GUI para control de la aplicación (p ej, seleccionar varios modelados?)

* Aplicacion de VAO y UBOs
* Instanciacion
* "transform feedback" (??)
* Aplicacion avanzada de texturas 
    * Ejemplo: mapas de desplazamiento
    * Ejemplo: niveles de detalle

--Ampliaciones--
* Deferred Shading?


Trabajo en progreso:

* Usar varios modelados (usar varios JSON?)

--DONETE--
* Movimiento de cámara libre
* Toonshading:
    * Requiere implementar Blinn-Phong
    * Deteccion y resaltado de siluetas.
    * Division del color en franjas cuantificadas.